### North Shouna Baths

| ![North Shouna Baths](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/north_shouna_baths.jpg) |
|-------------------------------------------------------------------------------------------------------------------------|
| *North Shouna Baths*                                                                                                    |

It was established in 1984 and is owned by the municipality of Moaz bin Jabal. It is located in the northern Shouneh
area. It is a therapeutic hot mineral water. It is one of the municipality’s income-generating projects, as it is leased
to a Jordanian investor and is considered a recreational and therapeutic area.

--------

## References

* [Ministry of Interior](https://moi.gov.jo/AR/Pages/%D8%A7%D9%84%D9%85%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%AD%D9%8A%D8%A9_%D9%81%D9%8A_%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9__%D8%A7%D8%B1%D8%A8%D8%AF)
