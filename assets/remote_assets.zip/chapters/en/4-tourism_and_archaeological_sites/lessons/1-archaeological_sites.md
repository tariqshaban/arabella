### Arar's Cultural House (Beit Arar)

| ![Arar's Cultural House](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/arar_cultural_house.jpg) |
|-----------------------------------------------------------------------------------------------------------------------------|
| *Arar's Cultural House (Beit Arar)*                                                                                         |

Beit Arar is located on the back of the industrial hill of Irbid, which was and still constitutes the heart and nucleus
of the city and its original spirit with its liberation and antiquity.
The house of the Jordanian poet “Arar” is characterized by spatial affinity, emotional warmth, and literary originality
that gives the visitor satisfaction, tranquility, and contemplation of what was, and the poet’s poetry that is still
resounding in the courtyard of the house, in the middle of which is a giant mulberry tree, and another at the entrance
to the house whose trunks formed a natural painting due to the age The tree, which is 100 years old, and still casts a
fresh shadow on visitors to the house and its space, which opens its doors from eight in the morning until three in the
morning, with the establishment of many literary seminars and local and Arab poetry evenings that are held in Jordan’s
festivals, poetry conferences and art exhibitions in the Arar Cultural House, which constitutes An emotional and
creative sign, and a cultural and civilizational landmark in Irbid's cultural and spatial path.
His library, his chair, and his bed, in addition to the poet’s pictures, books, writings, and dozens of Jordanian and
Arab press pages that dealt with Arar’s biography, poems, and stages of his national and national struggle against
British colonialism in Jordan and Palestine.

### Irbid Archeology Museum (Dar Al Saraya Museum)

| ![Dar Al Saraya Museum](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/dar-al_saraya.jpg) |
|----------------------------------------------------------------------------------------------------------------------|
| *Irbid Archeology Museum (Dar Al Saraya Museum)*                                                                     |

The Irbid Archeology Museum was established in the early sixties with the opening of the Irbid Archeology Office. It
was a single hall located on the back of the archaeological hill of Irbid. This hall contained some of the pieces that
were found during the archaeological excavations that were taking place in the governorate over time, and the number of
archaeological excavations in the governorate. In 1984, a building was rented in the southern district of the city of
Irbid, and the ground floor of it was allocated to be a large museum in which the discovered archaeological, Byzantine
and Islamic treasures are displayed.

### Umm Qais Museum and ruins

| ![Umm Qais](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/umm_qais1.jpg) |
|------------------------------------------------------------------------------------------------------|
| *Umm Qais Museum and ruins*                                                                          |

| ![Umm Qais](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/umm_qais2.jpg) |
|------------------------------------------------------------------------------------------------------|
| *Umm Qais Museum and ruins*                                                                          |

The museum is located inside the archaeological site in a heritage house (Bait al-Rusan) above the Acropolis of the
ancient city of Jadara (Umm Qais). The date of the construction of this house dates back to the end of the nineteenth
century AD, the late Ottoman period. The General Department of Antiquities acquired the building, and it was restored in
cooperation between The Department of Antiquities and the German Protestant Institute in 1990, when it was used as a
site museum for the ancient city of Umm Qais. The ground floor of the building, which consists of several rooms and an
inner courtyard, was used as a museum.

The Department of Antiquities has carried out maintenance and rehabilitation works on the upper floor, and maintenance
work will be completed on the ground floor and the courtyard.

### Tabaqat Fahl

| ![Tabaqat Fahl](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/tabaqat_fahl.jpg) |
|-------------------------------------------------------------------------------------------------------------|
| *Tabaqat Fahl*                                                                                              |

Tabaqat Fahal or (Bella) is considered one of the prominent archaeological monuments on the Jordanian tourism map. The
early days where there is a small mosque in it.

Tabqat Fahl was known in the past as Pella, a village in northwest Jordan, located to the east of the town of Mashari.
The city was built in the Hellenistic era during the period that witnessed the conquests of Alexander the Great. Pella
was named after the city in which Alexander was born.

The city was included in the ten-city alliance and many buildings were added to it in the centuries that followed the
conquest of the leader (Pompey) in 63 BC.

--------

## References

* [Ministry of Interior](https://moi.gov.jo/AR/Pages/%D8%A7%D9%84%D9%85%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%A3%D8%AB%D8%B1%D9%8A%D8%A9_%D9%81%D9%8A_%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9__%D8%A7%D8%B1%D8%A8%D8%AF)
