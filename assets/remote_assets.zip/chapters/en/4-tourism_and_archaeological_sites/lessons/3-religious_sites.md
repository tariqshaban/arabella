### The shrine of Muadh bin Jabal

| ![Muadh bin Jabal Shrine](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/muadh_bin_jabal.jpg) |
|--------------------------------------------------------------------------------------------------------------------------|
| *The shrine of Muadh bin Jabal*                                                                                          |

The shrine of Muadh bin Jabal in the northern Shouna, it is one of the most prominent shrines of the companions of the
Messenger of God in the region because of the standing of his companion with the Messenger of God, who described him, as
the most knowledgeable of his nation in the lawful and the forbidden, and he sent him as a judge to Yemen to teach them
the provisions of Sharia and the Noble Qur’an. He died in a plague.

The shrine includes a mosque for men and another for women, a library, the Islamic Cultural Center for men, a garden,
parking lots, a model school for the Holy Qur’an that the Ministry of Endowments has established, and other facilities
to increase religious services in the shrine and in proportion to the religious status of the owner of the shrine.

### The shrine of Shurahbil ibn Hasana

| ![Shurahbil ibn Hasana Shrine](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/shurahbil_ibn_hasana.jpg) |
|------------------------------------------------------------------------------------------------------------------------------------|
| *The shrine of Shurahbil ibn Hasana*                                                                                               |

Shurahbil ibn Hasana was distinguished by courage, sacrifice, generosity, intelligence and good management, which
prompted the Caliph Omar bin Al-Khattab, to take over the quarter of Sham. He died, in the plague of Amwas in the eighth
year of migration.

The shrine includes a chapel for men, a library, a garden, parking lots, a dome, a minaret, and an imam’s residence. As
for the shrine of Amer bin Abi Waqqas, it includes a chapel for men, a multi-purpose hall, a library, a garden, an
imam’s residence, and parking lots.

### The site of the Battle of Yarmouk

| ![Battle of Yarmouk](/assets/images/chapters/4-tourism_and_archaeological_sites/lessons_images/yarmouk_battle.jpg) |
|--------------------------------------------------------------------------------------------------------------------|
| *The site of the Battle of Yarmouk*                                                                                |

The site of the Battle of Yarmouk was in the year (15 AH - 636 AD) between the Muslims and the Byzantine Empire. Some
historians consider it one of the most important battles in the history of the world because it was the beginning of the
first wave of Muslim victories outside the Arabian Peninsula, and heralded the rapid progress of Islam in the Levant.
The battle took place four years after the death of the Prophet, may God bless him and grant him peace, in 632 AD.

--------

## References

* [Ministry of Interior](https://moi.gov.jo/AR/Pages/%D8%A7%D9%84%D9%85%D9%88%D8%A7%D9%82%D8%B9_%D8%A7%D9%84%D8%AF%D9%8A%D9%86%D9%8A%D8%A9_%D9%81%D9%8A_%D8%A7%D9%84%D9%85%D8%AD%D8%A7%D9%81%D8%B8%D8%A9__%D8%A7%D8%B1%D8%A8%D8%AF)
 