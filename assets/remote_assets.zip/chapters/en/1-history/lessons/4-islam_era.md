Irbid came under Islamic rule after the Battle of Yarmouk in the year 13 AH, where Sharhabeel bin Hasna led the Muslims
to victory over the Romans and control of the city. The city also remained prosperous in the Umayyad era; This is due to
its proximity to the capital of the caliphate, Damascus.

In 1596 it appeared in the Ottoman tax registers named as Irbid, situated in the nahiya (subdistrict) of Bani Juhma,
part of the Sanjak of Hawran. It had 72 households and 35 bachelors; all Muslims. The villagers paid a fixed tax-rate of
25% on agricultural products; including wheat (22,500 akçe), barley, summer crops, fruit trees, goats and bee-hives; in
addition to a market toll. The total tax was 38,116 akçe.

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Irbid)