In the Hellenistic period, Irbid, then known as Arabella was a major trade center. Before the advent of Islam, Arabella
was famous for producing some of the best wines in the ancient world. The area in the region had extremely fertile soil
and moderate climate, allowing the growing of high quality grapes.

The city was rebuilt along with the rest of the region's cities in a style influenced by the Greek style, the Greeks
wanted to make Irbid a center for the spread of Greek culture in the Levant, through intermarriage, friendships and
alliances, and military bases were established to protect trade convoys, and that To stand in the face of the Arab
tribes coming from the east. Irbid became at the heart of the roads between southern Syria and Mesopotamia on the one
hand, and the Palestinian coast and Egypt on the other. The rule in Irbid was autonomous in the Greek way, and it
controlled the surrounding areas of villages and farms, collected taxes from them and supervised the agriculture there.

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Irbid)