When the Emirate of Transjordan was established, the educational movement entered a new phase. The number of schools
increased and the spirit of modern education and modern programs changed. Schools spread in every neighborhood and
street of the city of Irbid, and there were schools in every village and town that included all levels of education.
Today, Irbid includes a number of intermediate university colleges, including Hawara College, Irbid College for Girls,
Al-Razi College, Ibn Khaldun College, Granada College, Cordoba College, Ajloun College, and Jerash College, in addition
to Yarmouk University and Al-Balqa Applied University, Al-Hosn Branch, in addition to the two private universities.

As of 2007, there were 70,000 registered students in Irbid's 10 universities, community colleges and institutes, of whom
8,000 were international students from 47 countries. This high concentration of institutions of higher education has
played a key role in carving a unique identity of the city.

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Irbid)