### Huwwarah College

| ![Huwwarah College](/assets/images/chapters/5-education/lessons_images/huwwarah_college.jpg) |
|----------------------------------------------------------------------------------------------|
| *Huwwarah College*                                                                           |

Huwwarah College is a former Jordanian public community college, located in the town of Huwwarah in the Irbid
Governorate in the north of the country. It was established in 1956 to be one of the oldest colleges in the Hashemite
Kingdom of Jordan. Teaching continued there until 1993, when it was suspended by a decision of the Jordanian government,
to turn its building into the headquarters of the College of Nursing, despite the popular objection to that.

The college premises are currently being used for the Nusaiba Al-Mazniah College of Midwifery and Nursing.

### Al-Quds College - Irbid Branch

| ![Al-Quds College](/assets/images/chapters/5-education/lessons_images/ltuc.jpg) |
|---------------------------------------------------------------------------------|
| *Al-Quds College*                                                               |

Al-Quds College in Jordan was established in 1983 and is part of **Luminus Education Group**. Al Quds College is a
private community college offering vocational two year diploma programs in six areas. All of its programs are accredited
by the Ministry of Higher Education and Scientific Research through Al Balqa University. To date, over 25,000 students
have graduated from Al Quds College. The current student population of the college is approximately 2,500 students.
Luminus Education is in talks with global education partners to strengthen Al Quds College's programs and provide
faculty and certification programs that are developed in cooperation with the industry in Jordan, raising the level of
training to Best International Standards. Al Quds also provides locally accredited career development programs (4–9
months) to individuals who have not graduated from high school or who are looking for a career change. All of its
trainers/facilitators come from the industry and offer both theoretical and practical expertise. After course completion
trainees have the option to sit for international examinations at the Pro-metric Testing Center to receive their passing
certificates.

### Granada College

| ![Granada College](/assets/images/chapters/5-education/lessons_images/granada_college.jpg) |
|--------------------------------------------------------------------------------------------|
| *Granada College*                                                                          |

Granada College is an intermediate community college, established in 1981, and it is the oldest private college in Irbid
Governorate, where the duration of study is two years under the supervision of Al-Balqa Applied University.

--------

## References

* [Wikipedia](https://ar.wikipedia.org/wiki/%D9%83%D9%84%D9%8A%D8%A9_%D8%AD%D9%88%D8%A7%D8%B1%D8%A9)
* [Wikipedia ₂](https://en.wikipedia.org/wiki/Al-Quds_College)
* [Wikipedia ₃](https://ar.wikipedia.org/wiki/%D9%83%D9%84%D9%8A%D8%A9_%D8%BA%D8%B1%D9%86%D8%A7%D8%B7%D8%A9)