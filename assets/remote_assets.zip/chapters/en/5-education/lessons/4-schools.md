Schools in the Irbid Governorate include the following:

* Summit International Academy
* King Abdullah school for excellence
* Adventist School
* Al-Arabiya Model School
* Al-Manara Schools
* Al-Nahda Private School
* Dar Al Uloum Schools
* Greek Catholic School
* International Grand Academy
* Islamic School (Al-Madares Al-Islamiya)
* Irbid International Schools
* Irbid Model School
* Jeel Al Jadeed School
* Jordan National Schools
* Khawla Bint Alazwar
* Shoa'a Alammel School
* Yarmouk University Model School

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/List_of_schools_in_Jordan)