### Jordan University of Science and Technology

| ![Jordan University of Science and Technology](/assets/images/chapters/5-education/lessons_images/jordan_university_of_science_and_technology.jpg) |
|----------------------------------------------------------------------------------------------------------------------------------------------------|
| *Jordan University of Science and Technology Campus*                                                                                               |

The Jordan University of Science and Technology, often abbreviated JUST, is a comprehensive, state-supported university
located on the outskirts of Irbid, at Ar Ramtha in northern Jordan. The University comprises twelve faculties that offer
a spectrum of undergraduate and higher study programs, in addition to King Abdullah University Hospital which is a
tertiary teaching hospital affiliated with JUST and located within its campus.

Having its roots at Yarmouk University in Irbid, a royal decree was issued in 1986 to establish JUST, which emerged as
an independent university on September 1, 1986. JUST detached five faculties from Yarmouk University to form its
academic nucleus. These faculties were: Faculty of Medicine, Faculty of Dentistry, Faculty of Pharmacy, Faculty of
Nursing and Faculty of Engineering. Consecutively added to these faculties were the Faculty of Science and Arts, Faculty
of Medical Applied Sciences, Faculty of Veterinary Medicine, Faculty of Computer and Information Technology, and the
Faculty of Agriculture.

Started with 110 faculty members, JUST in 2018 hosted 985 academic faculty members, of which 249 were full professors. A
total of 2,300 students enrolled in 1986, but as of the academic year 2017/2018, 22634 undergraduate and 2213
postgraduate students were enrolled at the university, representing 51 nationalities. The university granted 5177
Bachelor and Master Degrees in the academic year 2017/2018, with a total of over 77,000 graduates since establishment.

### Yarmouk University

| ![Yarmouk University](/assets/images/chapters/5-education/lessons_images/yarmouk_university.jpg) |
|--------------------------------------------------------------------------------------------------|
| *Yarmouk University Campus*                                                                      |

Yarmouk University, also abbreviated YU, is a comprehensive public and state supported university located near the city
centre of Irbid in northern Jordan. Since its establishment in 1976, Yarmouk University (YU) has been at the forefront
of Jordanian and Middle Eastern universities. The University consists of 15 faculties offering 52 bachelor's degrees, 64
master's degrees, and 18 PhD Programs in different disciplines. The university also hosts 12 research and career
centers.

As the Academic Year 2016/2017, the university has 1,004 faculty members and 1,597 staff with 34,651 students in all
academic programs (31,282 Undergraduate, 2,807 Postgraduate and 562 Doctoral). In addition, there are currently around
5,000 international students from 50 different nations.

### Irbid National University

| ![Irbid National University](/assets/images/chapters/5-education/lessons_images/irbid_national_university.jpg) |
|----------------------------------------------------------------------------------------------------------------|
| *Irbid National University Campus*                                                                             |

Irbid National University (abbreviated INU) is a university in Jordan. Established in 1994, it is located in the
northern town of Irbid. It has a student body of 6,000.

Irbid National University is a private university, certified by the Ministry of Higher Education and Scientific Research
of Jordan, the Islamic Association of Arab Universities (AARU), (FUW), and the Federation and European universities (
UNIMED). The university President is Prof. Mohammed Said Subbarini.

### Al-Balqa` Applied University (Al Husun College & Irbid University College)

| ![Al Husun College](/assets/images/chapters/5-education/lessons_images/al_husun_college.jpg) |
|----------------------------------------------------------------------------------------------|
| *Al Husun College Campus*                                                                    |

| ![Irbid University College](/assets/images/chapters/5-education/lessons_images/irbid_university_college.jpg) |
|--------------------------------------------------------------------------------------------------------------|
| *Irbid University College Campus*                                                                            |

Al-Balqaʼ Applied University (BAU) is a government-supported university located in Salt, Jordan, was founded in 1997, a
distinctive state university in the field of Bachelor and associate degree Applied Education, at the capacity of more
than 21,000 student distributed into 10,000 at the bachelor's degree program and 11,000 at the associate degree program.

Balqa' Applied University was formed by merging several colleges distributed over almost all of the Jordanian provinces.
The merger was the result of royal decree, under the auspices of his majesty the late King Hussein to provide qualified
professionals who focus on applied technical studies. A recent stadium was constructed to hold official graduation and
ceremonies and was finished in 2011.

BAU is ranked 5th on national level, and has achieved an international ranking of 2575 and a regional ranking of 55
according to the Webometrics Ranking of World Universities ranking, as well as a regional ranking of 79 according to US
News Education.

### Jadara University

| ![Jadara University](/assets/images/chapters/5-education/lessons_images/jadara_university.jpg) |
|------------------------------------------------------------------------------------------------|
| *Jadara University Campus*                                                                     |

Jadara University is a university located in the northern province of Irbid Governorate in Jordan, on the international
highway to the north of the city of Irbid, the governorate's capital.

Jadara University was approved by the Ministry of Higher Education and Scientific Research in November 2004, and was
established in the following year. It awards undergraduate and master's degrees mainly in Arabic, and English
literature, science, and information technology.

The university was named after the historic city of Gadara which is located about 20 km from the university campus.

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Irbid)
* [Wikipedia ₂](https://en.wikipedia.org/wiki/Jordan_University_of_Science_and_Technology)
* [Wikipedia ₃](https://en.wikipedia.org/wiki/Yarmouk_University)
* [Wikipedia ₄](https://en.wikipedia.org/wiki/Irbid_National_University)
* [Wikipedia ₅](https://en.wikipedia.org/wiki/Jadara_University)