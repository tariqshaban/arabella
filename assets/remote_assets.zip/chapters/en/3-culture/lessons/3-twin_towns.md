City twinning is basically an agreement between two cities to cooperate in various fields and matters that concern urban
residential communities. It is a cooperation agreement between two cities, usually signed by the highest authority in
both cities. A team from both cities prepares the terms of the agreement, and then in a ceremony in either one or both
cities alternately, the mayor, mayor, or mayor of each city signs a position known in English as Mayor. Usually this
agreement includes points that determine the extent and form of cooperation between the two cities in exchanging
information, experiences and solutions. Also, the two cities are usually linked by airlines directly, although this is
not a necessary condition. And relatively easy to travel between them.

The date of signing this agreement shall be considered the date of the beginning of the twinning. In the Arab world, the
Arab Towns Organization sponsors twinning agreements.

Irbid twin cities:

* Gaziantep, Turkey
* Zhengzhou, China
* Iași, Romania

| ![Gaziantep](/assets/images/chapters/3-culture/lessons_images/gaziantep.jpg) |
|------------------------------------------------------------------------------|
| *Gaziantep, Turkey*                                                          |

| ![Zhengzhou](/assets/images/chapters/3-culture/lessons_images/zhengzhou.jpg) |
|------------------------------------------------------------------------------|
| *Zhengzhou, China*                                                           |

| ![Iași](/assets/images/chapters/3-culture/lessons_images/iași.jpg) |
|--------------------------------------------------------------------|
| *Iași, Romania*                                                    |

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Sister_city)
* [Wikipedia ₂](https://en.wikipedia.org/wiki/Irbid)
