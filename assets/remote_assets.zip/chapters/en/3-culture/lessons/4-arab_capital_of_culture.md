The Arab Capital of Culture is an initiative of UNESCO similar to the European Capital of Culture. It began implementing
the idea of the Arab Cultural Capital in 1996, and this was based on a proposal by the Arab Group at UNESCO during the
meeting of the International Ten-Year Intergovernmental Committee for Cultural Development (Paris between January 3-7,
year 1995) and in The eleventh session of the Conference of Ministers Responsible for Cultural Affairs in the Arab
World, which was held in Sharjah in the United Arab Emirates (November 21-22, 1998).

The idea is based on the fact that culture is an important element in the life of society and an axis of comprehensive
development. It aims to activate creative initiatives and develop the cultural balance and the intellectual and
civilized stock, by highlighting the cultural value of the city hosting the events of the Cultural Capital event and
developing its key role in supporting intellectual and cultural creativity in deepening cultural dialogue and openness
to the cultures and civilizations of peoples and promoting values, understanding and fraternity, tolerance and respect
Cultural privacy.

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Arab_Capital_of_Culture)
