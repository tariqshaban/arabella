The traditional dishes are part of the Jordanian heritage, from the popular dishes in Irbid:

* Mansaf: It is the official and main dish in all governorates, and Jordan is also characterized by this popular food,
  especially among the Barhawis and the people of the Kasbah.
* Qalayet Bandora: It is indispensable for all classes of people in all governorates, which also distinguishes Jordan
  with this popular dish, especially among the Barhawis and the people of the Kasbah.
* Makmoura: It is one of the well-known dishes in the villages of northern Jordan and southern Syria.
* Kibbeh or kebab: It is known from the good food in the villages north of Irbid, such as (the villages of Bani Kenana).
* Murtabak: It is known from the good food in (the villages of Liwa Al-Taybeh and Al-Wasatiya), and it is a
  miniature food for the Makmoura.
* Al-Jaajil: (Al-Kaakil or Al-Shashael), and some or all Jordanian governorates sometimes share the same popular dishes,
  but Irbid’s dishes are closer to Daraa in Syria, because the Rabdawis form part of the Hawarana that extends between
  Syria and Jordan.
* Maqluba
* Latakia
* Joshpara
* Falafel and Shawarma sandwiches
* Chickpeas and beans
* kunafa

| ![Mansaf](/assets/images/chapters/3-culture/lessons_images/mansaf.jpg) |
|--------------------------------------------------------------------------------|
| *A Mansaf dish*                                                                |

| ![Maqluba](/assets/images/chapters/3-culture/lessons_images/maqluba.jpg) |
|---------------------------------------------------------------------------------|
| *A Maqluba dish*                                                                |

| ![Kunafa](/assets/images/chapters/3-culture/lessons_images/kunafa.jpg) |
|--------------------------------------------------------------------------------|
| *A Kunafa dish*                                                                |

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Irbid)
* [Wikipedia ₂](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%85%D8%A3%D9%83%D9%88%D9%84%D8%A7%D8%AA_%D8%A7%D9%84%D8%B4%D8%B9%D8%A8%D9%8A%D8%A9_%D9%81%D9%8A_%D8%A7%D9%84%D8%A3%D8%B1%D8%AF%D9%86)
