The city of Irbid contains multiple clubs in the Pro League, including: Al-Arabi, Al-Hussein, Al-Ramtha, Al-Sareeh, and
Kafrsum. Al-Arabi won the Jordan Cup in 1986, while Al-Hussein Irbid won the Federation Shield in 1994, 2002, 2005, the
Cup Winners’ Cup for the 2003 season, and Kafrsum won the Federation Shield in 1996.

Al-Arabi, Al-Hussein and Kafrsum clubs also participate in the Handball First Division Clubs League. These teams have a
long history in this game, as Al Arabi won the handball championship for 10 continuous years during the eighties and
nineties of the last century. As for the basketball league, Al-Hussein Club is competing for advanced positions. Irbid
athletes achieved advanced positions in several group and individual championships, including Talal Al-Anaqra, Maria
Muhammad Tariq Al-Barakat, Al-Hussein Technical Youth Center (1974 - 1979).

The Irbid-based club Al-Hussein (Irbid) was ranked fourth in the Jordanian football premier league in the year 2008. Its
home matches are held in Prince Hasan Youth City's Stadium. The other major football club in Irbid is Al-Arabi.
Established in 1945, it is one of the oldest athletic clubs in the country. As of 2008, there are 22 cultural and sport
clubs registered in Irbid. Irbid hosted the 1999 Pan Arab Games.

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Irbid)
