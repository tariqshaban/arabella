The demographic data of the 2015 Jordanian national census indicate that Irbid Governorate had a population of
1,770,158.

| Demographics of Irbid Governorate (2004 Census) | Value          |
|-------------------------------------------------|----------------|
| Female to Male ratio                            | 48.9% to 51.1% |
| Jordanian citizens to foreign nationals         | 96.6% to 3.4%  |
| Urban population                                | 707,420        |
| Rural population                                | 220,872        |
| Total population                                | 928,292        |

--------

## References

* [Wikipedia](https://en.wikipedia.org/wiki/Irbid_Governorate)